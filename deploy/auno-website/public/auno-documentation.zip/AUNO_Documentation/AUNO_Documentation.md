# AUNO Product Documentation

## Mainnet Beta Edition · 19 September 2026

### Payment Links, SOL / USDC checkout and Split Payments on Solana

AUNO helps individuals and teams request crypto payments and distribute funds across multiple wallets. Payment Links create shareable payment requests. Split Payments support allocation across recipient wallets using configured shares.

## Current release

| Capability | Mainnet Beta status |
| --- | --- |
| Payment Links | Available on Solana mainnet |
| Checkout assets | SOL and USDC active |
| Split Payments | Available on Solana mainnet |
| Escrow, milestones, streaming, subscriptions, API/SDK | Planned direction; not part of this release |

Mainnet uses real funds. Public Beta means the product is available for testing and feedback while reliability and usability improve. It does not mean every future feature is complete. This guide reflects the release status confirmed on 19 September 2026. It is a product guide, not a code audit or security certification.

## 1. Getting started

1. Open AUNO and connect a compatible Solana wallet.
2. Create a Payment Link with a title, amount, asset, receiving wallet, and optional description/reference/expiry.
3. Review the full recipient address, amount, asset, and network. Creation and payment are separate actions.
4. If requested, sign only the merchant message for link creation. It is different from transfer approval.
5. Share the generated URL. The URL is a payment request, not proof that funds were received.

Check the limits and fees displayed by the application. Do not assume unlimited amounts, fixed fees, or permanent recipient limits.

## 2. Checkout and transaction status

Checkout loads the stored request and shows the amount, asset, recipient, and Solana Mainnet network before wallet approval. The payer signs the transfer in their own wallet. A submitted signature is not a receipt: AUNO marks a payment paid only after finalized on-chain verification.

If finalization is pending, keep the payment link and transaction signature and retry verification. Do not send another payment only to refresh the page.

## 3. Split Payments

Mainnet Beta supports SOL and USDC Split Payments. Select the asset and total amount, add recipient wallets and shares, confirm that percentages total 100%, and review each calculated allocation before approval.

Example: 100 USDC can be allocated as 40 USDC to a designer, 40 USDC to a developer, and 20 USDC to a project lead. Network and displayed service fees are separate from allocations. After submission, verify the transaction details and recipient amounts.

Split Payments do not imply escrow, milestone approval, recurring settlement, dispute resolution, or saved team templates. Those capabilities are planned and are not represented as live in this release.

## 4. Verified receipts

A verified receipt includes the payment ID, amount, asset, recipient address or split allocations, payer, network, transaction signature, and chain timestamp. Explorer links open on Solana Mainnet. A signature alone is not proof of a finalized receipt.

## 5. Support and boundaries

- Wallet not detected: use a supported wallet/browser integration and reload after installing or enabling the wallet.
- Link cannot load: check the complete URL, connection, expiry, and creator confirmation.
- HTTP 422: capture the failing request and response; the status code alone does not identify the cause.
- Error after approval: check wallet history and the transaction signature before retrying.
- Funds moved but status is pending: keep the signature and link; do not duplicate the transfer.

When reporting an issue, include the link or request ID, time, asset/network, browser/wallet, visible error, and signature if one exists. Never share a seed phrase, private key, or API secret.

Current scope is Payment Links, SOL/USDC checkout, and Split Payments on Solana mainnet. Escrow, milestones, subscriptions, streaming, conditional payments, and developer integrations are planned. SOL and USDC are the checkout assets; $AUNO is not required or enabled as a checkout asset.

## 6. Roadmap

- **Stage 01 — Live / Public Beta:** Payment Links, SOL and USDC checkout, and Split Payments on Solana mainnet.
- **Stage 02 — Current Focus:** Reliability, payment status clarity, wallet compatibility, and feedback-led improvements.
- **Stage 03 — Planned:** Escrow and milestone-based releases, subject to authority and security design.
- **Stage 04 — Planned:** Subscriptions and payment streaming with explicit authorization and cancellation behavior.
- **Stage 05 — Planned / Exploratory:** API/SDK access, broader split capacity, and evaluation of additional networks.

Live identifies functionality in the current public beta. Planned identifies intended development, not an available product. This roadmap has no delivery dates; future features will be announced with their supported scope and release status when ready.

AUNO never requests seed phrases or private keys. No audit, insurance, guaranteed uptime, refund guarantee, or token investment outcome is claimed by this documentation.
