AUNO Documentation Package

Included:
- AUNO_Documentation.md
- AUNO_Documentation.html

Naming standard:
- Feature: Split Payment
- General capability: Split Payments

Main documentation intentionally excludes detailed Devnet/network configuration.
Those technical details can later live in a separate Developer Reference.
